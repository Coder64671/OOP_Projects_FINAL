import java.util.Random;
import java.util.Scanner;
/**
 * This program is used to make a deck of cards, shuffle the deck, and give the user their desired amount of cards.
 *
 * @author (Pratayanch Sav)
 * @version (10.28.2024)
 */
public class Card{
    public static void main(String[] args) {
        int index = 0;
        int totalPicked = 0;
        String[] ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" };
        String[] suits = { "Hearts", "Diamonds", "Clubs", "Spades" };
        String[] deck = new String[52];
        for (String suit : suits) {
            for (String rank : ranks) {
                deck[index] = rank + " of " + suit;
                index++;
            }
        }
        shuffleDeck(deck);
        Scanner scanner = new Scanner(System.in);
        while(totalPicked < 52){
            System.out.println("How many cards would you like to draw?");
            int numCards = scanner.nextInt();
            totalPicked += numCards;
            System.out.println("You drew:");
            for (int i = 0; i < numCards && i < deck.length; i++) {
                System.out.println(deck[i]);
            }
            bubbleSort(deck);
        }
    }

    // Shuffle method using random swapping of the cards.
    public static void shuffleDeck(String[] deck) {
        Random random = new Random();
        for (int i = 0; i < deck.length; i++) {
            int j = random.nextInt(deck.length);
            String temp = deck[i];
            deck[i] = deck[j];
            deck[j] = temp;
        }
    }
    
    // Bubble sort method using algorithm to put cards least to greatest.
    public static void bubbleSort(String[] deck){
        int n = deck.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (deck[j].compareTo(deck[j + 1]) > 0) {
                    // Swap if the current element is greater than the next element
                    String temp = deck[j];
                    deck[j] = deck[j + 1];
                    deck[j + 1] = temp;
                }
            }
        }
    }
    
}

