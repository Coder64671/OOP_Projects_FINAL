import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.List;

/**
 * 
 * Q1.) Name the package that you have to import to work with ArrayLists. 
 * >>> The package that I have to import in order to work with ArrayLists is
 *     'java.util.ArrayList;
 *     
 * Q2.) What do the angle brackets mean when you create an ArrayList?
 * >>> The angle brackets store the generic type of the collection within them.
 * 
 */
public class ALMethods
{
    ArrayList<String> words = new ArrayList<String>();
    // constructor, might not be used
    public ALMethods()
    {
    }
    
    // main method
    public void main(String[] args){
        try {
            Scanner fileIn = new Scanner(new File("words.txt"));
            while(fileIn.hasNext()){
                String lineIn = fileIn.nextLine();
                words.add(lineIn);
            }
        }catch(IOException e){
            System.out.println("File not found.");
        }
    }
    
    // accessor method
    public void printCollection(){
        for(String word : words){
            System.out.println(word);
        }
    }
    
    // Q3.) How do you find the number of elements present in an ArrayList?
    public int findNumberOfElements(){
        int numberElements;
        return words.size();
    }
    
    // Q4.) How do you find out whether the given ArrayList is empty or not? 
    public boolean findEmpty(){
        return words.isEmpty();
    }
    
    // Q5.) How do you check whether the given element is present in an ArrayList or not?
    public boolean findIfContains(){
        String string = "Instructor";
        return words.contains(string);
    }
    
    // Q6.) How do you get the position of a particular element in an ArrayList?
    public int findIndexOf(){
        String string = "Instructor";
        return words.indexOf(string);
    }
    
    // Q7.) How do you convert an ArrayList to Array? 
    public void convertToArray(){
        String[] wordsArray = words.toArray(new String[0]);
    }
    
    // Q8.) How do you retrieve an element from a particular position of an ArrayList?  
    public String getter(){
        int index = 3;
        return words.get(index);
    }
    
    // Q9.) How do you replace a particular element in an ArrayList with the given element?
    public void replace(){
        ListIterator<String> iterator = words.listIterator();
        iterator.next();
        iterator.set("Hello, World!");
        printCollection();
    }
    
    // Q10.) How do you append an element at the end of an ArrayList? 
    public void addElementAtEnd(){
        words.add("Hello, Planets!");
    }
    
    // Q11.) How do you insert an element at a particular position of an ArrayList? 
    public void addElementatIndex(){
        words.add(4, "Hello, Galaxy!");
    }
    
    // Q12.) How do you remove an element from a particular position of an ArrayList?  
    public void removeByIndex(){
        words.remove(1);
    }
    
    // Q13.) How do you remove the given element from an ArrayList?  
    public void removeByElement(){
        words.remove("Hello, World!");
    }
    
    // Q14.) How do you remove all elements of an ArrayList at a time?
    public void removeAll(){
        words.clear();
    }
    
    // Q15.) If you are given two ArrayLists, how do you join the two?  
    public void joinArrayList(){
        ArrayList<String> newWords = new ArrayList<String>();
        for(int i = 0; i <= 4; i++){
            newWords.add("Hello");
        }
        words.addAll(newWords);
    }
    
    // Q16.) How do you insert more than one element at a particular position of an ArrayList?  
    public void multipleElementAdd(){
        ArrayList<String> add = new ArrayList<String>();
        add.add("Hello");
        add.add("World");
        words.addAll(1, add);
    }
}
