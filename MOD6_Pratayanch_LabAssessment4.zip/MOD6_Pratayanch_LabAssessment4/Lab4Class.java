import java.io.*;
import java.util.*;
public class Lab4Class {
    // constructor method using hashmap
    public Lab4Class() {
        Map<String, String[]> employeeData = new HashMap<>();
        loadEmployeeData(employeeData);
        printEmployeeInfo(employeeData);
        printEmployees410(employeeData);
        printEmployeesSame(employeeData);
    }
    // Main method
    public static void main(String[] args) {
        new Lab4Class();  // Calling the constructor to initialize and process the employee data
    }
    // this method reads the input file
    private void loadEmployeeData(Map<String, String[]> employeeData){

        
        
        try (Scanner fileIn = new Scanner(new File("data-1.txt"))){
            String line;
            while (fileIn.hasNext()) {
                String lineIn = fileIn.nextLine();
                String[] parts = lineIn.split(" ");
                if (parts.length == 6) {
                    String name = parts[0] + " " + parts[1];
                    String[] phones = {parts[2], parts[3], parts[4]};
                    employeeData.put(name, phones);
                }
                System.out.println(lineIn);
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }
    // this method prints out the employee info
    private void printEmployeeInfo(Map<String, String[]> employeeData) {
        System.out.println("Employee Information:");
        System.out.printf("%-20s %-15s %-15s %-15s%n", "Name", "HomeNo", "WorkNo", "CellNo");
        for (Map.Entry<String, String[]> entry : employeeData.entrySet()) {
            String name = entry.getKey();
            String[] phones = entry.getValue();
            System.out.printf("%-20s %-15s %-15s %-15s%n", name, phones[0], phones[1], phones[2]);
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }
    // this method is to print out all the employees that live in area code 410
    private void printEmployees410(Map<String, String[]> employeeData) {
        System.out.println("Number of employees living in area code 410:");
        int count = 0;
        for (Map.Entry<String, String[]> entry : employeeData.entrySet()) {
            String[] phones = entry.getValue();
            if (phones[0].startsWith("410")) {  // Check if home phone number is from area code 410
                System.out.println(entry.getKey());
                count++;
            }
        }
        System.out.println("There are " + count + " employees living in area code 410");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }
    // this is the method to print out emplyees that live and work in the same code
    private void printEmployeesSame(Map<String, String[]> employeeData) {
        System.out.println("Number of employees live and work in same area code:");
        int count = 0;
        for (Map.Entry<String, String[]> entry : employeeData.entrySet()) {
            String[] phones = entry.getValue();
            if (phones[0].substring(0, 3).equals(phones[1].substring(0, 3))) {  // Compare area codes
                System.out.println(entry.getKey());
                count++;
            }
        }
        System.out.println("There are " + count + " employees live and work in the same area code");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }
}