import java.util.ArrayList;
import java.util.Scanner;

/**
 * A simple quiz program to demonstrate the use of ArrayLists and arrays.
 */
public class Quiz {

    private ArrayList<String> questions; // Stores the questions
    private ArrayList<String[]> answers; // Stores the multiple-choice options
    private char[] correctAnswers = {'c', 'd', 'a', 'c'}; // Correct answers
    private char[] userAnswers; // Stores user's answers
    private Scanner scanner;

    /**
     * Constructor to initialize ArrayLists and other resources.
     */
    public Quiz() {
        questions = new ArrayList<>();
        answers = new ArrayList<>();
        userAnswers = new char[4];
        scanner = new Scanner(System.in);
        populate();
    }

    /**
     * Populates the questions and answers from predefined data.
     */
    private void populate() {
        questions.add("1. Which of the following is the default value of a local variable?");
        answers.add(new String[]{
                "a. null",
                "b. \" \"",
                "c. local variables don't have a default value",
                "d. depends on the data type"
        });

        questions.add("2. Which index is the last element in a list called nums?");
        answers.add(new String[]{
                "a. nums.length",
                "b. nums.length - 1",
                "c. nums.size()",
                "d. nums.size()-1"
        });

        questions.add("3. Which of the following is a reason to use an ArrayList instead of an array?");
        answers.add(new String[]{
                "a. An ArrayList can grow or shrink as needed, while an array is always the same size",
                "b. You can use a for-each loop on an ArrayList, but not on an array",
                "c. You can store objects in an ArrayList, but not in any array",
                "d. All of the above"
        });

        questions.add("4. Which of the following is a reason to use an array instead of an ArrayList?");
        answers.add(new String[]{
                "a. An array has faster access to its elements than a list does.",
                "b. An array knows its length, but a list doesn't know its length.",
                "c. An ArrayList can allocate more space than it needs.",
                "d. None of the above"
        });
    }

    /**
     * Displays the quiz questions and records user responses.
     */
    public void createQuiz() {
        System.out.println("Welcome to the online quiz! Please select the best possible answer for each of the following:");
        for (int i = 0; i < questions.size(); i++) {
            System.out.println(questions.get(i));
            for (String option : answers.get(i)) {
                System.out.println(option);
            }
            System.out.print("Your answer please: ");
            userAnswers[i] = scanner.next().toLowerCase().charAt(0); // Record user's answer
        }
    }

    /**
     * Scores the quiz and displays the results.
     */
    public void score() {
        int correctCount = 0;

        for (int i = 0; i < correctAnswers.length; i++) {
            if (userAnswers[i] == correctAnswers[i]) {
                correctCount++;
            }
        }

        System.out.println("You scored " + correctCount + " correct answers out of 4");

        if (correctCount >= 3) {
            System.out.println("Congratulations! You passed the quiz.");
        } else {
            System.out.println("You did not earn a passing grade. You have some studying to do!");
        }
    }

    /**
     * Main method to run the quiz.
     * 
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        Quiz quiz = new Quiz();
        quiz.createQuiz();
        quiz.score();
    }
}