import java.util.Scanner;
public class Digits
{
    public Digits()
    {
        displayNumber();
    }
    
    public void displayNumber(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter a 2 digit number.");
        int scannerInput = scanner.nextInt();
        
        int firstDigit = scannerInput/10;
        int secondDigit = scannerInput%10;
        
        System.out.println("The first digit is: " + firstDigit + ", and the second digit is: " + secondDigit);
    }
}
