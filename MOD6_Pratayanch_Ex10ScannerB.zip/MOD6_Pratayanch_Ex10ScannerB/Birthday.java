import java.util.Scanner;
public class Birthday
{
    public Birthday()
    {
        output();
        mainBirthday();
    }
    
    public void output(){
        System.out.println("1. Determine your birth month (January=1, February=2 and so on)");
        System.out.println("2. Multiply that number by 5.");
        System.out.println("3. Add 6 to that number.");
        System.out.println("4. Multiply the number by 4");
        System.out.println("5. Add 9 to the number.");
        System.out.println("6. Multiply that number by 5.");
        System.out.println("7. Add your birth day to the number (10 if the 10th and so on).");
    }
    
    public void mainBirthday(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter your number: ");
        int userInput = scanner.nextInt();
        userInput = userInput - 165;
        int birthDay = userInput % 100;
        userInput = userInput / 100;
        int birthMonth = userInput % 100;
        System.out.println("The birthday is " + birthMonth + "/" + birthDay);
    }
}
