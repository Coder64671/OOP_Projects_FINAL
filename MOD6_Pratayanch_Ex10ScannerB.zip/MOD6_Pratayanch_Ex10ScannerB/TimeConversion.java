import java.util.Scanner;
public class TimeConversion
{
    public TimeConversion()
    {
        converter();
    }
    
    public void converter(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter an amount of time in minutes.");
        int time = scanner.nextInt();
        
        int hours = time/60;
        int minutes = time%60;
        System.out.println("The amount of time in hours and mintues is: " + hours + "hrs & " + minutes + "min");
    }
}
