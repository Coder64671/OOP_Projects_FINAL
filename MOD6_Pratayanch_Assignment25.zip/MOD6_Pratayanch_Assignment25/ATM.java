
/**
 * Write a description of class ATM here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.*;
import java.util.*;

public class ATM {
    private HashMap<Integer, ArrayList<Double>> accounts;

    // Constructor
    public ATM() {
        accounts = new HashMap<>();
        populate();
        menu();
    }

    // Method to populate accounts with data from a file
    private void populate() {
        try (BufferedReader reader = new BufferedReader(new FileReader("transactions.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(" ");
                int accountNumber = Integer.parseInt(data[0]);
                ArrayList<Double> transactions = new ArrayList<>();
                for (int i = 1; i < data.length; i++) {
                    transactions.add(Double.parseDouble(data[i]));
                }
                accounts.put(accountNumber, transactions);
            }
        } catch (IOException e) {
            System.out.println("Error reading transactions file: " + e.getMessage());
        }
    }

    // Menu for user interaction
    private void menu() {
        Scanner scanner = new Scanner(System.in);
        boolean continueUsing = true;

        while (continueUsing) {
            System.out.println("\nChoose one of the following:");
            System.out.println("1. Deposit money");
            System.out.println("2. Withdraw money");
            System.out.println("3. Print transaction for this account");
            System.out.println("4. Print ATM transactions");
            System.out.print("Your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> deposit(scanner);
                case 2 -> withdraw(scanner);
                case 3 -> printTransactionHistory(scanner);
                case 4 -> printAll();
                default -> System.out.println("Invalid choice. Please try again.");
            }

            System.out.print("Would you like to try out the ATM again? (y/n): ");
            continueUsing = scanner.next().equalsIgnoreCase("y");
        }

        System.out.println("Thank you for using my ATM machine!");
        scanner.close();
    }

    // Method to deposit money
    private void deposit(Scanner scanner) {
        System.out.print("Enter the account number: ");
        int account = scanner.nextInt();
        System.out.print("Enter the amount to deposit: ");
        double amount = scanner.nextDouble();

        ArrayList<Double> transactions = accounts.getOrDefault(account, new ArrayList<>());
        double currentBalance = transactions.isEmpty() ? 0 : transactions.get(transactions.size() - 1);
        transactions.add(amount);
        transactions.add(currentBalance + amount);
        accounts.put(account, transactions);

        System.out.println("Money deposited in the account.");
    }

    // Method to withdraw money
    private void withdraw(Scanner scanner) {
        System.out.print("Enter the account number: ");
        int account = scanner.nextInt();
        System.out.print("Enter the amount to withdraw: ");
        double amount = scanner.nextDouble();

        ArrayList<Double> transactions = accounts.get(account);
        if (transactions == null || transactions.isEmpty()) {
            System.out.println("Account does not exist.");
            return;
        }

        double currentBalance = transactions.get(transactions.size() - 1);
        if (currentBalance < amount) {
            System.out.println("Insufficient balance!");
            return;
        }

        transactions.add(-amount);
        transactions.add(currentBalance - amount);
        accounts.put(account, transactions);

        System.out.println("Money withdrawn from the account.");
    }

    // Method to get the current balance of an account
    private double getBalance(int account) {
        ArrayList<Double> transactions = accounts.get(account);
        return (transactions == null || transactions.isEmpty()) ? 0 : transactions.get(transactions.size() - 1);
    }

    // Method to print transaction history for a specific account
    private void printTransactionHistory(Scanner scanner) {
        System.out.print("Enter the account number: ");
        int account = scanner.nextInt();

        ArrayList<Double> transactions = accounts.get(account);
        if (transactions == null || transactions.isEmpty()) {
            System.out.println("Account does not exist.");
            return;
        }

        System.out.println("Account: " + account);
        System.out.print("Transactions: ");
        for (int i = 0; i < transactions.size() - 1; i++) {
            System.out.print(transactions.get(i) + " ");
        }
        System.out.println("Balance: " + getBalance(account));
    }

    // Method to print all transactions for all accounts
    private void printAll() {
        for (Map.Entry<Integer, ArrayList<Double>> entry : accounts.entrySet()) {
            int account = entry.getKey();
            ArrayList<Double> transactions = entry.getValue();

            System.out.println("Account: " + account);
            System.out.print("Transactions: ");
            for (int i = 0; i < transactions.size() - 1; i++) {
                System.out.print(transactions.get(i) + " ");
            }
            System.out.println("Balance: " + getBalance(account));
        }
    }

    // Main method to run the program
    public static void main(String[] args) {
        new ATM();
    }
}