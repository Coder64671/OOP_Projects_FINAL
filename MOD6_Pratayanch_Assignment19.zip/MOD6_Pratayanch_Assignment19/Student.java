
/**
 * Write a description of class Student here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Student {
    private String name;
    private int grade;
    private int hall;

    public Student(String name, int grade, int hall) {
        this.name = name;
        this.grade = grade;
        this.hall = hall;
    }

    public String getName() {
        return name;
    }

    public int getGrade() {
        return grade;
    }

    public int getHall() {
        return hall;
    }
}
