import java.util.*;
import java.io.*;
/**
 * Write a description of class Roster here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Roster {
    private ArrayList<Student> students;
    private Scanner scanner;

    public Roster() {
        students = new ArrayList<>();
        scanner = new Scanner(System.in);
        populate();
    }

    
    // used chatgpt to assist with skipping first line in populate method, and to help debug.
    public void populate() {
        try (Scanner fileScanner = new Scanner(new File("StudentInfo.txt"))) {
            boolean isFirstLine = true; // Flag to identify the first line
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine().trim();
                if (isFirstLine) {
                    isFirstLine = false; // Skip the first line
                    continue;
                }
                if (!line.isEmpty()) {
                    try {
                        String[] data = line.split("\\s+");
                        if (data.length < 4) {
                            throw new IllegalArgumentException("invalid line format: " + line);
                        }
                        String name = data[0] + " " + data[1]; 
                        int grade = Integer.parseInt(data[2]);
                        int hall = Integer.parseInt(data[3]);
                        students.add(new Student(name, grade, hall));
                    } catch (Exception e) {
                        System.out.println("error processing line: " + line);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Data file not found.");
        }
    }


    public void print() {
        System.out.print("Enter a grade level (10-12): ");
        int grade = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (grade < 10 || grade > 12) {
            System.out.println("Invalid grade level. Please enter 10, 11, or 12.");
            return;
        }

        System.out.printf("%-20s %-5s %-5s\n", "Name", "Grade", "Hall");
        for (Student student : students) {
            if (student.getGrade() == grade) {
                System.out.printf("%-20s %-5d %-5d\n", student.getName(), student.getGrade(), student.getHall());
            }
        }
    }

    public void find() {
        System.out.print("Enter the student's name: ");
        String name = scanner.nextLine();

        for (Student student : students) {
            if (student.getName().equalsIgnoreCase(name)) {
                System.out.printf("Name: %s, Grade: %d, Hall: %d\n",
                        student.getName(), student.getGrade(), student.getHall());
                return;
            }
        }
        System.out.println("Student not found.");
    }

    public void remove() {
        System.out.print("Enter the student's name to remove: ");
        String name = scanner.nextLine();

        Iterator<Student> iterator = students.iterator();
        while (iterator.hasNext()) {
            Student student = iterator.next();
            if (student.getName().equalsIgnoreCase(name)) {
                iterator.remove();
                System.out.println("Student removed successfully.");
                return;
            }
        }
        System.out.println("Student not found.");
    }

    public void analysis() {
        int[] hallCounts = new int[7];
        for (Student student : students) {
            hallCounts[student.getHall() - 1501]++;
        }

        for (int i = 0; i < hallCounts.length; i++) {
            System.out.printf("Hall %d: %d students\n", 1501 + i, hallCounts[i]);
        }
    }

    public static void main(String[] args) {
        Roster roster = new Roster();
        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Print students by grade");
            System.out.println("2. Find a student");
            System.out.println("3. Remove a student");
            System.out.println("4. Analyze hall data");
            System.out.println("5. Quit");

            int choice = roster.scanner.nextInt();
            roster.scanner.nextLine(); 

            switch (choice) {
                case 1 -> roster.print();
                case 2 -> roster.find();
                case 3 -> roster.remove();
                case 4 -> roster.analysis();
                case 5 -> {
                    System.out.println("Thank you for using the roster program!");
                    return;
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
