import java.util.Random;
import java.util.Scanner;
public class Quiz
{
    public Quiz()
    {
        randomBig();
        quizTemplate();
    }
    
    public void randomBig(){
        Random randy = new Random();
        int randomNumber = randy.nextInt(400)+100;
        System.out.println("The random number between 100 and 500 is " + randomNumber);
    }
    
    public int randomNumberGenerator(){
        Random randy = new Random();
        int randomNumber = randy.nextInt(400)+100;
        return randomNumber;
    }
    
    public void quizTemplate(){
        int sub1 = 0;
        int sub2 = 0;
        int score = 0;
        System.out.println("*****************************************************************************");
        System.out.println("                       * Welcome to KRISH’s Quiz Page!                        "); 
        System.out.println("   You are to answer 4 questions to test your arithmetic skills. Good luck!  ");
        System.out.println("*****************************************************************************");
        sub1 = randomNumberGenerator();
        sub2 = randomNumberGenerator();
        int answer1 = sub1 + sub2;
        System.out.println("                           Q1.) " + sub1 + " + " + sub2);
        sub1 = randomNumberGenerator();
        sub2 = randomNumberGenerator();
        int answer2 = sub1 - sub2;
        System.out.println("                           Q2.) " + sub1 + " - " + sub2);
        sub1 = randomNumberGenerator();
        sub2 = randomNumberGenerator();
        int answer3 = sub1 * sub2;
        System.out.println("                           Q3.) " + sub1 + " * " + sub2);
        sub1 = randomNumberGenerator();
        sub2 = randomNumberGenerator();
        int answer4 = sub1 / sub2;
        System.out.println("                           Q4.) " + sub1 + " / " + sub2);
        System.out.println("*****************************************************************************");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter answer for question 1: ");
        int ans1 = scanner.nextInt();
        if(ans1 == answer1){
            System.out.println("Correct!");
            score += 1;
        }else{
            System.out.println("Incorrect");
        }
        System.out.println("Please enter answer for question 2: ");
        int ans2 = scanner.nextInt();
        if(ans2 == answer2){
            System.out.println("Correct!");
            score += 1;
        }else{
            System.out.println("Incorrect");
        }
        System.out.println("Please enter answer for question 3: ");
        int ans3 = scanner.nextInt();
        if(ans3 == answer3){
            System.out.println("Correct!");
            score += 1;
        }else{
            System.out.println("Incorrect");
        }
        System.out.println("Please enter answer for question 4: ");
        int ans4 = scanner.nextInt();
        if(ans4 == answer4){
            System.out.println("Correct!");
            score += 1;
        }else{
            System.out.println("Incorrect");
        }
        int percent = (score/4) * 100; 
        System.out.println("you got " + percent + "%");
        System.out.println("Would you like to take it again? (y/n)");
        String repeat = scanner.nextLine();
        if(repeat == "y"){
            quizTemplate();
        }else{
            scienceQuiz();
        }
    }
    
    public void scienceQuiz(){
        int score = 0;
        System.out.println("*****************************************************************************");
        System.out.println("                       * Welcome to KRISH’s Quiz Page!                        "); 
        System.out.println("   You are to answer 4 questions to test your arithmetic skills. Good luck!  ");
        System.out.println("*****************************************************************************");
        System.out.println("            Q1.) What is the first element of the periodic table?");
        System.out.println("            Q2.) What is the main source of energy?");
        System.out.println("            Q3.) What is the distance between the earth and the sun?");
        System.out.println("            Q4.) How long does it take for sunlight to reach the earth?");
        System.out.println("*****************************************************************************");
        System.out.println("enter in all lowercase without units");
        String answer1 = "hydrogen";
        Scanner scanner = new Scanner(System.in);
        String ans1 = scanner.nextLine();
        if(ans1 == answer1){
            System.out.println("Correct!");
            score += 1;
        }else{
            System.out.println("Incorrect");
        }
        String answer2 = "sun";
        String ans2 = scanner.nextLine();
        if(ans2 == answer2){
            System.out.println("Correct!");
            score += 1;
        }else{
            System.out.println("Incorrect");
        }
        String answer3 = "93.292";
        String ans3 = scanner.nextLine();
        if(ans3 == answer3){
            System.out.println("Correct!");
            score += 1;
        }else{
            System.out.println("Incorrect");
        }
        String answer4 = "8.3";
        String ans4 = scanner.nextLine();
        if(ans4 == answer4){
            System.out.println("Correct!");
            score += 1;
        }else{
            System.out.println("Incorrect");
        }
        int percent = (score/4) * 100; 
        System.out.println("you got " + percent + "%");
        System.out.println("Would you like to take it again? (y/n)");
        String repeat = scanner.nextLine();
        if(repeat == "y"){
            scienceQuiz();
        }        
    }
}
