import java.util.Scanner;
import java.util.Random;
public class Numbers
{
    
    /*
     * ex1.) rand.nextInt(4)+1; 
     * ex2.) rand.nextInt(3);
     * ex3.) rand.nextInt(5)+5;
     * ex4.) rand.nextInt(8)-4;
     * ex5.) rand.nextInt(7)*2+16;
     * 
     * Is there any other way to create a random number?
     * A.) Yes, there are many different classes in Java which can create a random number, one of which is ThreadLocalRandom, which aids in creating random numbers.
     */
    
    public Numbers()
    {
        genNumber();
        genRange();
        getRangeModified();
    }
    
    public void genNumber(){
        Random randy = new Random();
        int randNum = randy.nextInt(10);
        System.out.println("Random number is : " + randNum);
    }
    
    public void genRange(){
        Random randy = new Random();
        int randNum = randy.nextInt(2)+1;
        if(randNum == 1){
            System.out.println("Good Morning");            
        } else if(randNum == 2){
            System.out.println("Good Afternoon");
        } else{
            System.out.println("Good Evening");
        }
    }
    
    public void getRangeModified(){
        Scanner scanner = new Scanner(System.in);
        Random randy = new Random();
        System.out.println("Enter min: ");
        int min = scanner.nextInt();
        System.out.println("Enter max");
        int max = scanner.nextInt();
        int randNum = randy.nextInt(max-min)+min;
        System.out.println("The random number between " + min + " & " + max + " is " + randNum);
    }
}
