
/**
 * Write a description of class StrExercise here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class StrExercise
{
    public StrExercise()
    {
        converter();
    }

    public void converter()
    {
        System.out.println("The character " + 'A' + " has the value" + (int) 'A');
        System.out.println("The character " + 'B' + " has the value" + (int) 'B');
        System.out.println("The character " + 'C' + " has the value" + (int) 'C');
        System.out.println("The character " + 'a' + " has the value" + (int) 'a');
        System.out.println("The character " + 'b' + " has the value" + (int) 'b');
        System.out.println("The character " + 'c' + " has the value" + (int) 'c');
        System.out.println("The character " + '0' + " has the value" + (int) '0');
        System.out.println("The character " + '1' + " has the value" + (int) '1');
        System.out.println("The character " + '2' + " has the value" + (int) '2');
        System.out.println("The character " + '$' + " has the value" + (int) '$');
        System.out.println("The character " + '*' + " has the value" + (int) '*');
        System.out.println("The character " + '+' + " has the value" + (int) '+');
        System.out.println("The character " + '/' + " has the value" + (int) '/');
    }
}
