import java.util.Scanner;
/**
 * Write a description of class MyScanner here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MyScanner
{
    
    public MyScanner()
    {
        sumAverage();
        getFirstAndLast();
        uppercaseWord();
        lexoComparison();
        stringChanger();
        firstAndLastNameReversePrinter();
    }
    
    public void sumAverage(){
        System.out.println("Please enter 5 numbers.");
        Scanner scanner = new Scanner(System.in);
        double input1 = scanner.nextDouble();
        System.out.println("Stored, enter next number: ");
        double input2 = scanner.nextDouble();
        System.out.println("Stored, enter next number: ");
        double input3 = scanner.nextDouble();
        System.out.println("Stored, enter next number: ");
        double input4 = scanner.nextDouble();
        System.out.println("Stored, enter next number: ");
        double input5 = scanner.nextDouble();
        System.out.println("Stored, Calculating...");
        
        double add = input1 + input2 + input3 + input4 + input5;
        double average = add/5;
        
        System.out.println("The sum of the 5 numbers is " + add);
        System.out.println("The avereage of the 5 numbers is " + average);
    }
    
    public void getFirstAndLast(){
        System.out.println("Please enter a string.");
        Scanner scanner = new Scanner(System.in);
        String scannerInput = scanner.nextLine();
        System.out.println(scannerInput.substring(scannerInput.length()-(scannerInput.length()), scannerInput.length()-(scannerInput.length()-1)));
        System.out.println(scannerInput.substring(scannerInput.length()-1));
    }
    
    public void uppercaseWord(){
        System.out.println("Please enter a string.");
        Scanner scanner = new Scanner(System.in);
        String scannerInput = scanner.nextLine();
        int counter = 0;
        for (int i = 0; i < scannerInput.length(); i++) {
            if (scannerInput.substring(i, i + 1).equals(" ")) {
                counter = i;
                break;
            }
        }
        System.out.println(scannerInput.substring(0, 1).toUpperCase() + scannerInput.substring(1, counter) + " " + scannerInput.substring(counter + 1, counter + 2).toUpperCase() + scannerInput.substring(counter + 2));
    }
    
    public void lexoComparison(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter 1st string.");
        String scannerInput1 = scanner.nextLine();
        System.out.println("Please enter 2nd string.");
        String scannerInput2 = scanner.nextLine();
        int result = scannerInput1.compareTo(scannerInput2);
        if(result < 0){
            System.out.println(scannerInput1 + " is lexicographically smaller than " + scannerInput2);
        }else if(result > 0){
            System.out.println(scannerInput1 + " is lexicographically larger than " + scannerInput2);
        }else{
            System.out.println(scannerInput1 + " is lexicographically equal to " + scannerInput2);
        }
    }
    
    public void stringChanger(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input special string (HelloWorld).");
        String scannerInput = scanner.nextLine();
        System.out.println(scannerInput.substring(0,scannerInput.length()/2).toUpperCase() + scannerInput.substring(scannerInput.length()/2));
    }
    
    public void firstAndLastNameReversePrinter(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input your first name.");
        String firstName = scanner.nextLine();
        System.out.println("Input your last name.");
        String lastName = scanner.nextLine();
        StringBuilder sb = new StringBuilder(firstName);
        StringBuilder sb2 = new StringBuilder(lastName);
        String reverseFirst = sb.reverse().toString();
        String reverseLast = sb2.reverse().toString();
        System.out.println(reverseLast + " " + reverseFirst);
    }
}
