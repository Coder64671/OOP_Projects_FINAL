import java.io.*;
import java.util.*;

public class Lab4 {

    // Constructor
    public Lab4() {
        Map<String, String[]> employeeData = new HashMap<>();
        
        // Load data from file
        loadEmployeeData(employeeData);
        
        // Process and print information
        printEmployeeInformation(employeeData);
        printEmployeesInAreaCode410(employeeData);
        printEmployeesLivingAndWorkingInSameAreaCode(employeeData);
    }

    public static void main(String[] args) {
        new Lab4(); // Start the program
    }

    // Method to load employee data from file
    private void loadEmployeeData(Map<String, String[]> employeeData) {
        String fileName = "employees.txt"; // Change to your file path if needed
        try (BufferedReader reader = new BufferedReader(new FileReader("data-1.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split line into parts
                String[] parts = line.trim().split("\\s+");
                if (parts.length == 5) {
                    String name = parts[0] + " " + parts[1]; // Combine first and last name
                    String[] phoneNumbers = { parts[2], parts[3], parts[4] };
                    employeeData.put(name, phoneNumbers); // Add to HashMap
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found. Please ensure 'employees.txt' is in the correct location.");
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }

    // Method to print all employee information
    private void printEmployeeInformation(Map<String, String[]> employeeData) {
        System.out.println("Employee Information:");
        System.out.printf("%-20s %-15s %-15s %-15s%n", "Name", "HomeNo", "WorkNo", "CellNo");
        for (Map.Entry<String, String[]> entry : employeeData.entrySet()) {
            String name = entry.getKey();
            String[] phones = entry.getValue();
            System.out.printf("%-20s %-15s %-15s %-15s%n", name, phones[0], phones[1], phones[2]);
        }
        System.out.println("************************************************");
    }

    // Method to print employees living in area code 410
    private void printEmployeesInAreaCode410(Map<String, String[]> employeeData) {
        System.out.println("************************************************");
        System.out.println("Number of employees living in area code 410:");
        int count = 0;
        for (Map.Entry<String, String[]> entry : employeeData.entrySet()) {
            String[] phones = entry.getValue();
            if (phones[0].startsWith("410")) { // Check if home number starts with 410
                System.out.println(entry.getKey());
                count++;
            }
        }
        System.out.println("There are " + count + " employees living in area code 410.");
        System.out.println("************************************************");
    }

    // Method to print employees living and working in the same area code
    private void printEmployeesLivingAndWorkingInSameAreaCode(Map<String, String[]> employeeData) {
        System.out.println("************************************************");
        System.out.println("Number of employees living and working in the same area code:");
        int count = 0;
        for (Map.Entry<String, String[]> entry : employeeData.entrySet()) {
            String[] phones = entry.getValue();
            // Compare the first three digits (area code) of home and work phone numbers
            if (phones[0].substring(0, 3).equals(phones[1].substring(0, 3))) {
                System.out.println(entry.getKey());
                count++;
            }
        }
        System.out.println("There are " + count + " employees living and working in the same area code.");
        System.out.println("************************************************");
    }
}