/**
 * Introduction



HashMap is a part of the Java Collections Framework that stores key-value pairs. It provides the
basic implementation of the Map interface of Java.
// HashMap declaration
HashMap<KeyType, ValueType> hashMap = new HashMap<>();
Methods
put(KeyType key, ValueType value): Adds a key-value pair to the HashMap.
get(Object key): Retrieves the value associated with the key.
containsKey(Object key): Checks if the key exists in the HashMap.
containsValue(Object value): Checks if the value exists in the HashMap.
remove(Object key): Removes the key-value pair associated with the key.
keySet(): Returns a Set containing all the keys.
entrySet(): Returns a Set containing all key-value pairs.
Example
import java.util.HashMap;
public class HashMapExample {
public static void main(String[] args) {
// Creating a HashMap
HashMap<String, Integer> studentGrades = new HashMap<>();
// Adding key-value pairs
studentGrades.put("Alice", 95);
studentGrades.put("Bob", 87);
studentGrades.put("Charlie", 76);
// Accessing a value using get()
System.out.println("Bob's grade: " + studentGrades.get("Bob"));
// Checking if a key exists
if (studentGrades.containsKey("Alice")) {
System.out.println("Alice's grade exists: " + studentGrades.get("Alice"));
}
CS 205 HashMaps in Java FS 2024
// Removing a key
studentGrades.remove("Charlie");
// Iterating through the HashMap
for (String student : studentGrades.keySet()) {
System.out.println(student + "'s grade: " + studentGrades.get(student));
}
}
}
HashMap in Java provides a convenient way to store key-value pairs and retrieve values based
on keys efficiently. It's widely used in various applications for its speed and versatility in
managing data.
In Java, the HashMap class does not guarantee any specific order of its elements. The
elements are not stored in the order they are inserted. However, starting from Java 8, there's an
alternative implementation called LinkedHashMap that maintains the order of elements in which
they were inserted.
In a HashMap, elements don't move up or down when items are added or removed. The
positions of elements within a HashMap are determined by their hash codes and handled by the
underlying data structure, which typically uses an array of linked lists or a more efficient
mechanism such as a red-black tree (for Java 8 onward).
When an element is added to a HashMap, its position within the data structure is determined by
the computed hash code of the key. If the position is already occupied (hash collision), elements
are stored in a linked list (or a tree in the case of Java 8 onwards) in that position, without
causing the existing elements to move around.
Similarly, when an element is removed, only the connections in the linked list (or the structure
maintained in case of trees) are altered, without affecting the positions of other elements. The
absence of that element leaves gaps in the linked list or structure, but it doesn't cause the entire
structure to shift.
This is why the iteration order or positions of elements won't change due to adding or removing
elements, as long as the rehashing threshold isn't crossed, triggering a reorganization of the
hash table.
If you need to maintain the order of elements in which they were inserted, LinkedHashMap
should be used, as it maintains a doubly-linked list to track the insertion order without affecting
the position of other elements when elements are added or removed.
CS 205 HashMaps in Java FS 2024
compare and contrast arraylist and hashmap
ArrayList and HashMap are both part of the Java Collections Framework, but they serve
different purposes and have distinct characteristics:
ArrayList:
Data Structure:
Implements a dynamic array that can dynamically grow or shrink as needed.
Ordering:
Maintains elements in the order they are inserted. Elements can be accessed using their index
(position in the list).
Duplicates:
Allows duplicate elements.
Access Time:
Provides fast access using index-based retrieval (constant-time complexity O(1)).
Usage:
Ideal for situations where elements need to be accessed frequently by their index, and when the
focus is on maintaining the order of elements.
HashMap:
Data Structure:
Utilizes a hash table structure to store key-value pairs.
Ordering:
Does not maintain the order of elements; the order in which elements are stored is not
guaranteed.
Duplicates:
Does not allow duplicate keys. Values can be duplicates, but each key must be unique.
Access Time:
Provides quick key-based retrieval of values (average constant-time complexity O(1)).
Usage:
Suitable for scenarios where quick lookup times are needed and when data needs to be
organized by keys for efficient retrieval.
Comparison:
Purpose:
CS 205 HashMaps in Java FS 2024
• ArrayList is used to store and manipulate lists of elements in a specific order, allowing
fast access via indexes.
• HashMap is designed to store key-value pairs, enabling quick lookup of values based on
keys.
Data Structure:
• ArrayList utilizes a resizable array for its internal structure.
• HashMap uses a hash table for key-value pair storage.
Ordering:
• ArrayList maintains the order of elements.
• HashMap doesn’t maintain any particular order.
Duplication:
• ArrayList allows duplicate elements.
• HashMap doesn’t allow duplicate keys but permits duplicate values.
Access Method:
• ArrayList provides access via indexes.
• HashMap provides access using keys.
Both ArrayList and HashMap are important data structures in Java, serving different needs
based on how data needs to be stored, accessed, and manipulated. Understanding their
differences is crucial in choosing the appropriate one based on the requirements of a particular
scenario.







What is an ArrayList?
The ArrayList class is a Java class that you can use to store lists of objects. You can also store objects in an
array, but arrays have a couple of obvious problems.
To create an array, you have to specify a size for the array. Sometimes you won't know what size array
you will need at the instant you create the array.
Although it is possible to resize arrays by creating a new, larger array and copying data over from the
old array, doing this is clunky and awkward.
The primary goal of the Java ArrayList class is to provide a class that replicates many of the features of
arrays, while adding some new features that are designed to work around the problems listed above.
Basics of ArrayLists
To create an ArrayList object you use the following syntax.
ArrayList<Type> A = new ArrayList<Type>();
Here Type is the type that you are planning to store in the ArrayList. For example, to make an ArrayList that
can hold Strings you would do
ArrayList<String> B = new ArrayList<String>();
A fundamental limitation of ArrayLists is that they can only hold objects, and not primitive types such as
ints.
ArrayList<int> C = new ArrayList<int>();
// Illegal - int is not an object type
The workaround for this is that Java provides a class equivalent for every one of the primitive types. For
example, there is an Integer class corresponding to the int type and a Double class corresponding to the
double type, and so on. The first step to being able to store a list of ints in an ArrayList is to instead create
an ArrayList that can hold a list of Integer objects:
ArrayList<Integer> D = new ArrayList<Integer>();
// OK - Integer is an object type
When you create an ArrayList, the list you get is initially empty. To add new items to the end of the ArrayList
you use the add() method:
ArrayList<String> B = new ArrayList<String>(); // B starts out empty.
B.add("Hello"); // B now has size 1
B.add("World"); // B new has size 2
Adding items to an ArrayList of Integers is similar:
ArrayList<Integer> D = new ArrayList<Integer>();
D.add(new Integer(3)); // D now has size 1
D.add(new Integer(15)); // D now has size 2
An alternative way to add ints to an ArrayList is to use the autoboxing feature. This feature automatically
converts primitive types into their object equivalents:
ArrayList<Integer> D = new ArrayList<Integer>();
D.add(3); // D now has size 1
D.add(15); // D now has size 2
To retrieve items from an ArrayList, use the get() method.
ArrayList<Integer> D = new ArrayList<Integer>();
D.add(3);
D.add(15);
int x = D.get(1); // x is now 15
To determine the size of an ArrayList, use the size() method.
ArrayList<Integer> D = new ArrayList<Integer>();
D.add(3);
D.add(15);
D.add(-46);
for(int n = 0;n < D.size();n++)
System.out.println(D.get(n));
To replace an existing value with a new value, use the set() method:
ArrayList<Integer> D = new ArrayList<Integer>();
D.add(3); // Location 0 is 3
D.add(15);
D.add(-46);
D.set(0,22); // Location 0 is now 22
Along with being to add items and have the list resize automatically to accomodate them, you can also
remove items and have the list shrink automatically each time you remove an item. To remove an item, use
the remove() method with the index of the item you want to remove. For example, to remove the last item
in an ArrayList you would do
D.remove(D.size() - 1);






CS 205 Object Oriented Programming FS 2024
File Input/Output
As we start to use our programs to analyze more and more information, having a way to import and export information
becomes critical. This is where file input and output become important. In this tutorial, we are going to look at a few things.
First, we are going to take a look at how we read in lines from a file. We will then look at some very basic string manipulation
to split our lines. Finally, we will look at how we can write out results to a file.
Reading from a file
The basic process to read in from file is the following:
• Create an Scanner object using the input file
• Loop through each line and read it in
o After reading in the line, process the line
o Move on to the next line
• Exit the loop after reading in all lines.
Set up your Text file. Call it input.txt
Hello
World
Today is a very fine day!
Code to Scanner File
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
public class MyProgram
{
public static void main(String[] args)
{
/* We must use a try/catch when reading
* in a file in case the file is not found

try {
// Create the Scanner object using the file
// as input
Scanner fileIn = new Scanner(new File("input.txt"));
/* Loop while the file still has lines.
* .hasNext() looks to see if a line exists
* but it doesn't read the line.

while (fileIn.hasNext())
{
// Reads the entire line
String lineIn = fileIn.nextLine();
// Output the line
System.out.println(lineIn);
}
}
catch (IOException e) {
System.out.println("File not found");
}
}
}
CS 205 Object Oriented Programming FS 2024
Basic string manipulation
Different files may contain different information and we may not just want each line to be its own string variable.
The two most common things that we would need to do with a file input are splitting the line into pieces and
transforming a string into a number. Below is an example, of how we might do this to sum lines of integer,
Set up your Text file. Call it input.txt
446,499,748,453,135
109,525,721,179,796
622,944,175,303,882
287,177,185,828,423
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
public class MyProgram
{
public static void main(String[] args)
{
try {
Scanner fileIn = new Scanner(new File("input.txt"));
while (fileIn.hasNext())
{
// Reads the entire line as a string
String lineIn = fileIn.nextLine();
// Split the line into a String array
String[] input = lineIn.split(",");
int sum = 0;
for (int i = 0; i < input.length; i ++) {
sum += Integer.parseInt(input[i]);
}
System.out.println(sum);
}
}
catch (IOException e) {
System.out.println("File not found");
}
}
}
CS 205 Object Oriented Programming FS 2024Example: READ FILE
Create a text file. Move it to the current projects folder
one 1000
two 2000
three 3000
four 4000
Code to Read File
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
/**
* This class reads an input file.

public class ReadFile
{
// instance variables - replace the example below with your own
private String[] s;
/**
* Constructor for objects of class ReadFile

public ReadFile(String a)throws FileNotFoundException
{
File text = new File(a);
Scanner scan = new Scanner(text);
String line = "";
s = new String[4];
int i = 0;
while (scan.hasNextLine())
{
line = scan.nextLine();
s[i] = line;
i = i + 1;
}
int total = 0;
String[] s1 = new String[2];
for (int j = 0; j < s.length; j ++)
{
s1 = s[j].split(" ");
total = total + Integer.parseInt(s1[1]);
}
System.out.println("The total is --> "+ total);
}
}
CS 205 Object Oriented Programming FS 2024
Code to Write File
import java.io.*;
/**
* This class implements how to write to a file.

public class Write_File
{
// instance variables - replace the example below with your own
private FileOutputStream out;
private PrintStream ps;
/**
* Constructor for objects of class Write_File
* The name of the file would be the input.

public Write_File(String s)
{
try
{
out = new FileOutputStream(s);
ps = new PrintStream(out);
}
catch(Exception e)
{
System.out.println("Error opening the file");
}
}
public void write(String s)
{
try
{
ps.println(s);
}
catch(Exception e)
{
System.out.println("Error while writing to the file");
}
}
public void close()
{
try
{
ps.close();
}
catch(Exception e)
{
System.out.println("Error closing the file");
}
}
}







CS 205 Arrays in Java 21 October 2024
Introduction: Arrays are fundamental data structures in Java, allowing programmers to store
and manipulate collections of elements of the same data type. They provide a convenient way to
work with a fixed-size list of items.
Advantages of Arrays in Java:
Efficient Data Storage: Arrays allocate memory in a contiguous block, making it efficient for
accessing elements by index. This results in faster access times compared to other data
structures.
Fixed Size: Arrays have a fixed size, which can be an advantage when you know the number of
elements you need to store in advance. It ensures data integrity and prevents accidental
overflows.
Simplicity: Arrays are straightforward to declare and use in Java, making them an excellent
choice for storing homogeneous data.
Performance: Iterating through an array is usually faster than some other data structures like
ArrayList due to better cache locality.
Type Safety: Arrays are type-safe, meaning they can only store elements of a specific data type,
which helps prevent data type-related errors.
Disadvantages of Arrays in Java:
Fixed Size: The fixed size of arrays can also be a limitation when the number of elements to
store is dynamic and unknown in advance. It requires managing resizing manually.
Inflexibility: Once an array is created with a specific size, it cannot be changed. If you need to
add or remove elements dynamically, you may need to create a new array and copy the contents.
Sparse Data: Arrays are not efficient for storing sparse data where many elements are null or
empty, as they still consume memory.
Limited Functionality: Arrays lack built-in methods for common operations like sorting,
searching, or resizing. You must implement these functionalities yourself or use other data
structures.
Examples of Arrays in Java:
Declaring an Array:
int[] numbers = new int[5]; // Declares an integer array of size 5
String[] names = new String[3]; // Declares a string array of size 3
Initializing an Array:
int[] scores = {85, 92, 78, 95, 88}; // Initializes an integer array with
values
CS 205 Arrays in Java 21 October 2024
String[] fruits = {"Apple", "Banana", "Orange"}; // Initializes a string
array with values
Accessing Array Elements:
int firstScore = scores[0]; // Accesses the first element (85)
String fruit = fruits[1]; // Accesses the second element ("Banana")
Iterating Through an Array:
for (int i = 0; i < scores.length; i++) {
System.out.println("Score " + i + ": " + scores[i]);
}
Conclusion: Arrays in Java are powerful and efficient data structures with advantages like
efficient data storage, simplicity, and type safety. However, their fixed size and lack of dynamic
resizing can be limiting in certain scenarios. It's essential to consider your program's
requirements when choosing whether to use arrays or other data structures like ArrayLists or
LinkedLists to best meet your needs.
CS 205 Java Arrays October 24
Understanding Java Arrays
In Java, an array is a data structure that allows you to store multiple values of the same data type
in a single variable. Arrays are commonly used in programming to manage collections of data,
such as lists of numbers, strings, or objects. Each value in an array is called an element, and each
element is accessed by its position, or index, within the array.
Declaring an Array: To declare an array in Java, you need to specify its data type, followed by
square brackets [] and a name for the array. Here's an example of declaring an array of integers:
int[] numbers;
Creating an Array: After declaring an array, you need to create it using the new keyword and
specify the number of elements it can hold. For example, to create an array of integers that can
hold 5 elements:
numbers = new int[5];
You can also declare and create an array in a single line:
int[] numbers = new int[5];
Initializing an Array: You can initialize the values of an array when you create it. Here's how
you can create and initialize an array of integers:
int[] numbers = {10, 20, 30, 40, 50};
Accessing Array Elements: Array elements are accessed using their index, starting from 0 for
the first element. For example, to access the first element (10) in the numbers array:
int firstNumber = numbers[0];
Modifying Array Elements: You can change the value of an array element by assigning a new
value to it using its index. For instance, to change the second element (20) in the numbers array:
numbers[1] = 25;
Array Length: You can determine the number of elements in an array using the length property.
For example:
int arrayLength = numbers.length; // This will be 5
Iterating Through an Array: You can use loops, like for loops, to iterate through the elements
of an array. Here's an example that prints all elements in the numbers array:
for (int i = 0; i < numbers.length; i++) {
System.out.println(numbers[i]); }
Arrays of Other Data Types: Arrays can hold values of any data type, including strings,
floating-point numbers, or custom objects. Just declare the array with the appropriate data type:
String[] names = {"Alice", "Bob", "Charlie"};
CS 205 Java Arrays October 24
double[] prices = {19.99, 29.99, 39.99};
Array Index Out of Bounds: Be careful not to access elements outside the array bounds, as it
will result in an ArrayIndexOutOfBoundsException. Always ensure that your index is within
the valid range of 0 to arrayLength - 1.
Arrays in most programming languages are fixed-size collections because they allocate a
contiguous block of memory at the time of creation. This fixed size is determined when you
declare and create the array. There are several reasons why arrays have a fixed size:
1. Memory Allocation: When an array is created, it needs to allocate a specific amount of
memory to store its elements. This memory allocation is done upfront, and it's not
practical to resize the allocated memory block every time an element is added or
removed. Resizing can be a costly operation in terms of time and resources.
2. Efficient Access: Arrays provide constant-time (O(1)) access to elements because they
use indices to directly access elements in memory. To maintain this efficiency, the
elements must be stored in a contiguous block of memory with fixed addresses. If the size
were dynamic, the addresses of elements would have to change whenever the array is
resized, making access less efficient.
How Arrays Are Stored in Memory: Arrays are stored in memory as a contiguous block of
memory locations, with each element occupying a fixed amount of space. The elements are
stored one after the other in sequential memory locations. When you access an element using its
index, the computer calculates the memory address of that element by considering the base
address of the array and the size of each element.
For example, consider an array of integers:
int[] numbers = {10, 20, 30, 40, 50};
In memory, it might be represented as follows (assuming 4 bytes per integer):
Copy code
| 10 | 20 | 30 | 40 | 50 |
Each element (e.g., 10) is stored in a contiguous memory location, and the index (0, 1, 2, 3, 4) is
used to calculate the address of each element.
What Happens When a Middle Element Is Removed: When an element is removed from the
middle of an array, there is a gap left in the array. The gap is typically filled by moving all the
elements that come after the removed element one position to the left. This operation can be
time-consuming, especially if the array is large or if elements are removed frequently from the
middle.
For example, if you remove the element at index 2 (30) from the array above, the array would be
modified like this:
Before removal:
CS 205 Java Arrays October 24
Copy code
| 10 | 20 | 30 | 40 | 50 |
After removal:
| 10 | 20 | 40 | 50 | |
The element at index 2 is removed, and the elements to the right of it (40 and 50) are shifted one
position to the left to fill the gap.
This shifting process has a time complexity of O(n), where n is the number of elements to the
right of the removed element. If you need to perform frequent insertions or removals in the
middle of a collection, other data structures like linked lists may be more efficient, as they don't
require shifting elements.
In the example where you remove the element at index 2 (30) from the array, and the elements to
the right are shifted one position to the left, the last element in the modified array will still hold
its original value.
After the removal of 30, the array looks like this:
| 10 | 20 | 40 | 50 | |
In this modified array, the last element (at index 4) still contains its original value, which is 50,
until you manually set it to null. Removing an element from the middle of the array does not
change the values of the elements that were not directly affected by the removal.
Summary:
• Arrays are used to store multiple values of the same data type.
• Declare, create, and initialize arrays.
• Access and modify array elements using indices.
• Use loops for iterating through arrays.
• Arrays can hold values of various data types.
With this understanding, you can efficiently work with arrays in Java, which is essential for
many programming tasks. Practice and experimentation will help solidify your knowledge of
arrays.
Chapter 8 Arrays
Up to this point, the only variables we have used were for individual values such as numbers or
strings. In this chapter, we’ll learn how to store multiple values of the same type using a single
variable. This language feature will enable you to write programs that manipulate larger amounts of
data.
8.1 Creating arrays
An array is a sequence of values; the values in the array are called elements. You can make an array
of int s, double s, or any other type, but all the values in an array must have the same type.
To create an array, you have to declare a variable with an array type and then create the array itself.
Array types look like other Java types, except they are followed by square brackets ( [] ). For
example, the following lines declare that counts is an “integer array” and values is a “double
array”:
int[] counts;
double[] values;
To create the array itself, you have to use the new operator, which we rst saw in Section 3.2
(https://books.trinket.io/thinkjava/chapter3.html#scanner):
counts = new int[4];
values = new double[size];
The rst assignment makes count refer to an array of four integers. The second makes values
refer to an array of double , where the number of elements in values depends on the value of size .
Of course, you can also declare the variable and create the array in a single line of code:
int[] counts = new int[4];
double[] values = new double[size];
You can use any integer expression for the size of an array, as long as the value is nonnegative. If you
try to create an array with −4 elements, for example, you will get a NegativeArraySizeException .
An array with zero elements is allowed, and there are special uses for such arrays that we’ll see later
on.
(//trinket.io/)
Think Java 1st Ed. (https://books.trinket.io/thinkjava/index.html) MENU ()
8.2 Accessing elements
When you create an array of int s, the elements are initialized to zero. Figure 8.1 shows a state
diagram of the counts array so far.
Figure 8.1: State diagram of an int array.
The arrow indicates that the value of counts is a reference to the array. You should think of the
array and the variable that refers to it as two dierent things. As we’ll soon see, we can assign a
dierent variable to refer to the same array, and we can change the value of counts to refer to a
dierent array.
The large numbers inside the boxes are the elements of the array. The small numbers outside the
boxes are the indexes (or indices) used to identify each location in the array. Notice that the index of
the rst element is 0, not 1, as you might have expected.
The [] operator selects elements from an array:
System.out.println("The zeroth element is " + counts[0]);
You can use the [] operator anywhere in an expression:
counts[0] = 7;
counts[1] = counts[0] * 2;
counts[2]++;
counts[3] -= 60;
Figure 8.2 shows the result of these statements.
Figure 8.2: State diagram after several assignment statements.
You can use any expression as an index, as long as it has type int . One of the most common ways to
index an array is with a loop variable. For example:
int i = 0;
while (i < 4) {
System.out.println(counts[i]);
i++;
}
This while loop counts from 0 up to 4. When i is 4, the condition fails and the loop terminates. So
the body of the loop is only executed when i is 0, 1, 2, and 3.
Each time through the loop we use i as an index into the array, displaying the i th element. This
type of array processing is often written using a for loop.
for (int i = 0; i < 4; i++) {
System.out.println(counts[i]);
}
For the counts array, the only legal indexes are 0, 1, 2, and 3. If the index is negative or greater than
3, the result is an ArrayIndexOutOfBoundsException .
8.3 Displaying arrays
You can use println to display an array, but it probably doesn’t do what you would like. For
example, the following fragment (1) declares an array variable, (2) makes it refer to an array of four
elements, and (3) attempts to display the contents of the array using println :
int[] a = {1, 2, 3, 4};
System.out.println(a);
Unfortunately, the output is something like:
[I@bf3f7e0
The bracket indicates that the value is an array, I stands for “integer”, and the rest represents the
address of the array. If we want to display the elements of the array, we can do it ourselves:
public static void printArray(int[] a) {
System.out.print("{" + a[0]);
for (int i = 1; i < a.length; i++) {
System.out.print(", " + a[i]);
}
System.out.println("}");
}
Given the previous array, the output of this method is:
{1, 2, 3, 4}
The Java library provides a utility class java.util.Arrays that provides methods for working with
arrays. One of them, toString , returns a string representation of an array. We can invoke it like this:
System.out.println(Arrays.toString(a));
And the output is:
[1, 2, 3, 4]
As usual, we have to import java.util.Arrays before we can use it. Notice that the string format is
slightly dierent: it uses square brackets instead of curly braces. But it beats having to write the
printArray method.
8.4 Copying arrays
As explained in Section 8.2, array variables contain references to arrays. When you make an
assignment to an array variable, it simply copies the reference. But it doesn’t copy the array itself!
For example:
double[] a = new double[3];
double[] b = a;
These statements create an array of three double s and make two dierent variables refer to it, as
shown in Figure 8.3.
Figure 8.3: State diagram showing two variables that refer to the same array.
Any changes made through either variable will be seen by the other. For example, if we set
a[0] = 17.0 , and then display b[0] , the result is 17.0. Because a and b are dierent names for
the same thing, they are sometimes called aliases.
If you actually want to copy the array, not just a reference, you have to create a new array and copy
the elements from the old to the new, like this:
double[] b = new double[3];
for (int i = 0; i < 3; i++) {
b[i] = a[i];
}
Another option is to use java.util.Arrays , which provides a method named copyOf that copies an
array. You can invoke it like this:
double[] b = Arrays.copyOf(a, 3);
The second parameter is the number of elements you want to copy, so you can also use copyOf to
copy just part of an array.
8.5 Array length
The examples in the previous section only work if the array has three elements. It would be better to
generalize the code to work with arrays of any size. We can do that by replacing the magic number,
3 , with a.length :
double[] b = new double[a.length];
for (int i = 0; i < a.length; i++) {
b[i] = a[i];
}
All arrays have a built-in constant, length , that stores the number of elements. The expression
a.length may look like a method invocation, but there are no parentheses and no arguments.
The last time this loop gets executed, i is a.length - 1 , which is the index of the last element.
When i is equal to a.length , the condition fails and the body is not executed – which is a good
thing, because trying to access a[a.length] would throw an exception.
You can also use a.length with Arrays.copyOf :
double[] b = Arrays.copyOf(a, a.length);
8.6 Array traversal
Many computations can be implemented by looping through the elements of an array and
performing an operation on each element. For example, the following loop squares the elements of a
double array:
for (int i = 0; i < a.length; i++) {
a[i] = Math.pow(a[i], 2.0);
}
Looping through the elements of an array is called a traversal. Another common pattern is a search,
which involves traversing an array looking for a particular element. For example, the following
method takes an int array and an integer value, and it returns the index where the value appears:
public static int search(double[] a, double target) {
for (int i = 0; i < a.length; i++) {
if (a[i] == target) {
return i;
}
}
return -1;
}
If we nd the target value in the array, we return its index immediately. If the loop exits without
nding the target, it returns -1 , a special value chosen to indicate a failed search.
Another common traversal is a reduce operation, which “reduces” an array of values down to a
single value. Examples include the sum or product of the elements, the minimum, and the
maximum. The following method takes a double array and returns the sum of the elements:
public static double sum(double[] a) {
double total = 0.0;
for (int i = 0; i < a.length; i++) {
total += a[i];
}
return total;
}
Before the loop, we initialize total to zero. Each time through the loop, we update total by adding
one element from the array. At the end of the loop, total contains the sum of the elements. A
variable used this way is sometimes called an accumulator.
8.7 Random numbers
Most computer programs do the same thing every time they run; programs like that are
deterministic. Usually determinism is a good thing, since we expect the same calculation to yield the
same result. But for some applications, we want the computer to be unpredictable. Games are an
obvious example, but there are many others.
Making a program nondeterministic turns out to be hard, because it’s hard for a computer to
generate truly random numbers. But there are algorithms that generate unpredictable sequences
called pseudorandom numbers. For most applications, they are as good as random.
If you did Exercise 4 (https://books.trinket.io/thinkjava/chapter3.html#guess), you have already
seen java.util.Random , which generates pseudorandom numbers. The method nextInt takes an
integer argument, n , and returns a random integer between 0 and n - 1 (inclusive).
If you generate a long series of random numbers, every value should appear, at least approximately,
the same number of times. One way to test this behavior of nextInt is to generate a large number of
values, store them in an array, and count the number of times each value occurs.public static int search(double[] a, double target) {
for (int i = 0; i < a.length; i++) {
if (a[i] == target) {
return i;
}
}
return -1;
}
If we nd the target value in the array, we return its index immediately. If the loop exits without
nding the target, it returns -1 , a special value chosen to indicate a failed search.
Another common traversal is a reduce operation, which “reduces” an array of values down to a
single value. Examples include the sum or product of the elements, the minimum, and the
maximum. The following method takes a double array and returns the sum of the elements:
public static double sum(double[] a) {
double total = 0.0;
for (int i = 0; i < a.length; i++) {
total += a[i];
}
return total;
}
Before the loop, we initialize total to zero. Each time through the loop, we update total by adding
one element from the array. At the end of the loop, total contains the sum of the elements. A
variable used this way is sometimes called an accumulator.
8.7 Random numbers
Most computer programs do the same thing every time they run; programs like that are
deterministic. Usually determinism is a good thing, since we expect the same calculation to yield the
same result. But for some applications, we want the computer to be unpredictable. Games are an
obvious example, but there are many others.
Making a program nondeterministic turns out to be hard, because it’s hard for a computer to
generate truly random numbers. But there are algorithms that generate unpredictable sequences
called pseudorandom numbers. For most applications, they are as good as random.
If you did Exercise 4 (https://books.trinket.io/thinkjava/chapter3.html#guess), you have already
seen java.util.Random , which generates pseudorandom numbers. The method nextInt takes an
integer argument, n , and returns a random integer between 0 and n - 1 (inclusive).
If you generate a long series of random numbers, every value should appear, at least approximately,
the same number of times. One way to test this behavior of nextInt is to generate a large number of
values, store them in an array, and count the number of times each value occurs.
The following method creates an int array and lls it with random numbers between 0 and 99. The
argument species the size of the array, and the return value is a reference to the new array.
public static int[] randomArray(int size) {
Random random = new Random();
int[] a = new int[size];
for (int i = 0; i < a.length; i++) {
a[i] = random.nextInt(100);
}
return a;
}
The following fragment generates an array and displays it using printArray from Section 8.3:
int numValues = 8;
int[] array = randomArray(numValues);
printArray(array);
The output looks like this:
{15, 62, 46, 74, 67, 52, 51, 10}
If you run it, you will probably get dierent values.
8.8 Traverse and count
If these values were exam scores – and they would be pretty bad exam scores – the teacher might
present them to the class in the form of a histogram. In statistics, a histogram is a set of counters
that keeps track of the number of times each value appears.
For exam scores, we might have ten counters to keep track of how many students scored in the 90s,
the 80s, etc. To do that, we can traverse the array and count the number of elements that fall in a
given range.
The following method takes an array and two integers, low and high . It returns the number of
elements that fall in the range from low to high .
public static int inRange(int[] a, int low, int high) {
int count = 0;
for (int i = 0; i < a.length; i++) {
if (a[i] >= low && a[i] < high) {
count++;
}
}
return count;
}
This pattern should look familiar: it is another reduce operation. Notice that low is included in the
range ( >= ), but high is excluded ( < ). This detail keeps us from counting any scores twice.
Now we can count the number of scores in each grade range:
int[] scores = randomArray(30);
int a = inRange(scores, 90, 100);
int b = inRange(scores, 80, 90);
int c = inRange(scores, 70, 80);
int d = inRange(scores, 60, 70);
int f = inRange(scores, 0, 60);
8.9 Building a histogram
The previous code is repetitious, but it is acceptable as long as the number of ranges is small. But
suppose we wanted to keep track of the number of times each score appears. We would have to write
100 lines of code:
int count0 = inRange(scores, 0, 1);
int count1 = inRange(scores, 1, 2);
int count2 = inRange(scores, 2, 3);
...
int count99 = inRange(scores, 99, 100);
What we need is a way to store 100 counters, preferably so we can use an index to access them. In
other words, we need another array!
The following fragment creates an array of 100 counters, one for each possible score. It loops
through the scores and uses inRange to count how many times each score appears. Then it stores
the results in the array:
int[] counts = new int[100];
for (int i = 0; i < counts.length; i++) {
counts[i] = inRange(scores, i, i + 1);
}
Notice that we are using the loop variable i three times: as an index into the counts array, and as
two arguments for inRange . The code works, but it is not as ecient as it could be. Every time the
loop invokes inRange , it traverses the entire array.
It would be better to make a single pass through the array, and for each score, compute which range
it falls in and increment the corresponding counter. This code traverses the array of scores only once
to generate the histogram:
int[] counts = new int[100];
for (int i = 0; i < scores.length; i++) {
int index = scores[i];
counts[index]++;
}
Each time through the loop, it selects one element from scores and uses it as an index to increment
the corresponding element of counts . Because this code only traverses the array of scores once, it is
much more ecient.
8.10 The enhanced for loop
Since traversing arrays is so common, Java provides an alternative syntax that makes the code more
compact. For example, consider a for loop that displays the elements of an array on separate lines:
for (int i = 0; i < values.length; i++) {
int value = values[i];
System.out.println(value);
}
We could rewrite the loop like this:
for (int value : values) {
System.out.println(value);
}
This statement is called an enhanced for loop. You can read it as, “for each value in values ”. It’s
conventional to use plural nouns for array variables and singular nouns for element variables.
Notice how the single line for (int value : values) replaces the rst two lines of the standard
for loop. It hides the details of iterating each index of the array, and instead, focuses on the values
themselves.
Using the enhanced for loop, and removing the temporary variable, we can write the histogram
code from the previous section more concisely:
int[] counts = new int[100];
for (int score : scores) {
counts[score]++;
}
Enhanced for loops often make the code more readable, especially for accumulating values. But
they are not helpful when you need to refer to the index, as in search operations.
for (double d : array) {
if (d == target) {
// array contains d, but we don't know the index
}
}
8.11 Vocabulary
array:






CS205 Scanner Class – introduction FS 2024
Introduction to the Scanner Class
In Java, the Scanner class is a part of the java.util package and provides a convenient way to
read and parse input from various sources, such as the console, files, or strings. It allows you to
break down input into tokens and process them individually. The Scanner class is widely used
for tasks like user input validation, reading data from files, and more.
Creating a Scanner Object
To use the Scanner class, you first need to create a Scanner object. This object is associated
with a particular input source, like the console or a file. Here's how you create a Scanner object
to read from the console:
import java.util.Scanner;
public class ScannerExample {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
// Your code to read and process input goes here
scanner.close(); // Remember to close the scanner when
you're done
}
}
Basic Input Reading
Reading Strings
The Scanner class provides methods to read different types of input. To read a string, you can
use the next() method:
String name = scanner.next();
System.out.println("Hello, " + name);
Reading Integers
To read an integer, you can use the nextInt() method:
int age = scanner.nextInt();
System.out.println("You are " + age + " years old.");
Reading Doubles
For reading double values, you can use the nextDouble() method:
double temperature = scanner.nextDouble();
System.out.println("The temperature is " + temperature + "
degrees Celsius.");
CS 205 Scanner Class – introduction FS 2024
Reading Characters
To read a single character, you can use the next().charAt(0) combination:
char gender = scanner.next().charAt(0);
System.out.println("Gender: " + gender);
Input Validation
The Scanner class allows you to perform input validation by checking if the input matches a
certain pattern using regular expressions. The hasNext() method can be used to determine if the
next token matches the expected pattern.
if (scanner.hasNextInt()) {
int number = scanner.nextInt();
System.out.println("You entered: " + number);
} else {
System.out.println("Invalid input. Please enter an
integer.");
}
Using Delimiters
By default, the Scanner class uses whitespace as the delimiter, which separates input into tokens
based on spaces, tabs, and newline characters. You can also specify a custom delimiter using the
useDelimiter() method.
scanner.useDelimiter(",");
while (scanner.hasNext()) {
String token = scanner.next();
System.out.println("Token: " + token);
}
Closing the Scanner
After you're done reading input, it's important to close the Scanner object to release any
associated resources. You can use the close() method for this:
scanner.close();
Example: Summing a List of Numbers
Here's an example that demonstrates how to use the Scanner class to read a list of numbers from
the console and calculate their sum:
import java.util.Scanner;
public class SumCalculator {
CS205 Scanner Class – introduction FS 2024
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
System.out.println("Enter numbers separated by
spaces:");
double sum = 0.0;
while (scanner.hasNextDouble()) {
double number = scanner.nextDouble();
sum += number;
}
System.out.println("Sum: " + sum);
scanner.close();
}
}
Conclusion
The Scanner class in Java is a powerful tool for reading and processing different types of input.
Its flexibility and ease of use make it an essential part of any Java programmer's toolkit. Whether
you're reading user input from the console or parsing data from files, the Scanner class offers a
wide range of functionalities to simplify the process.






Java’s Scanner String input method
To take String input from the user with Java’s Scanner class, just follow these steps
1. Import java.util.*; to make Java’s Scanner class available
2. Use the new keyword to create an instance of the Scanner class
3. Pass the static System.in object to the Scanner’s Java constructor
4. Use Scanner’s next() method to take input one String at a time
5. Optionally use the Scanner’s hasNext() method to loop over the process
String user input example
The following example uses the Java Scanner class to take String input from the user:
import java.util.Scanner;
public class ScannerUserInput {
public static void main(String[] args) {
// String input with the Java Scanner
System.out.println("How old are you?");
Scanner stringScanner = new Scanner(System.in);
String age = stringScanner.next();
System.out.println(age + " is a good age to be!");
}
}
Scanner user input processing
Now imagine a user types in 20 30 40 50 at the console. What happens?
Here’s the result:
How old are you?
20 30 40 50
20 is a good age to be!
Notice how the output includes only the first String the Java Scanner read. The rest of the text is
ignored.
This is because the Scanner class tokenizes the input String based on any whitespace between
words.
Scanner hasNext example
To get each individual text String, we must create a loop and iterate through the input String with the
Scanner’s hasNext() method:
System.out.println("How old are you?");
Scanner stringScanner = new Scanner(System.in);
// Process each Java Scanner String input
while (stringScanner.hasNext()) {
String age = stringScanner.next();
System.out.println(age + " is a good age to be!");
}
If the user now types in 20 30 40 50, the program iterates through the text String four times, once for
each number.
Here’s the output of the updated Scanner String input processing program:
How old are you?
20 30 40 50
20 is a good age to be!
30 is a good age to be!
40 is a good age to be!
50 is a good age to be!
Scanner next vs nextLine for user input
As we have seen, the Scanner’s next() method consumes a line of text, tokenizes the input based on
any whitespace, and then iteratively loops through each individual item. The
Scanner’s nextLine() method works a bit differently.
In contrast to next(), nextLine() does not tokenize input. It simply returns a complete line of text.
In this example, we change from the Scanner next() method to the nextLine()
method and compare the results:
System.out.println("How old are you?");
Scanner stringScanner = new Scanner(System.in);
// Process each Java Scanner String input
while (stringScanner.hasNext()) {
String age = stringScanner.nextLine();
System.out.println(age + " is a good age to be!");
}
How old are you?
20 30 40 50
20 30 40 50 is a good age to be!
Notice how the input is not split up, or tokenized, into separate, individual Strings?
The difference between the Java Scanner’s next() and nextLine() methods is that next() chunks a line
of input into individual text Strings, while nextLine() returns an entire line of user input exactly the way
it was sent to the Scanner.How old are you?
20 30 40 50
20 is a good age to be!
30 is a good age to be!
40 is a good age to be!







CS205 Java Random Numbers FS 2024
Random numbers play a crucial role in various applications, ranging from simulations and games
to cryptography and statistical analysis. In Java, you can generate random numbers using the
java.util.Random class or the Math.random() method. This document will guide you through
both methods of generating random numbers and provide examples to help you understand the
concepts.
Ref: https://docs.oracle.com/javase/8/docs/api/java/util/Random.html (Random)
https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html (Math)
Table of Contents
1. Introduction to java.util.Random
2. Generating Random Integers with java.util.Random
3. Generating Random Doubles with java.util.Random
4. Generating Random within a Range with java.util.Random
5. Seeding the Random Generator with java.util.Random
6. Generating Random Numbers with Math.random()
7. Example Applications
8. Conclusion
1. Introduction to java.util.Random
The java.util.Random class is a part of the Java standard library and offers methods to
generate random numbers of different types, such as integers, doubles, and more. It uses a seed
value to initialize its internal state, which then generates a sequence of pseudo-random
numbers.
2. Generating Random Integers with java.util.Random
To generate random integers, you can use the nextInt() method. It returns a random integer
from the entire range of possible integers (-2,147,483,648 to 2,147,483,647), including
negative values.
import java.util.Random;
public class RandomIntegerExample {
public static void main(String[] args) {
Random random = new Random();
int randomNumber = random.nextInt();
System.out.println("Random Integer: " + randomNumber);
}
CS205 Java Random Numbers FS 2024
3. Generating Random Doubles with java.util.Random
To generate random double values between 0.0 (inclusive) and 1.0 (exclusive), you can use the
nextDouble() method.
import java.util.Random;
public class RandomDoubleExample {
public static void main(String[] args) {
Random random = new Random();
double randomDouble = random.nextDouble();
System.out.println("Random Double: " + randomDouble);
}
}4. Generating Random within a Range with java.util.Random
To generate random numbers within a specific range, you can use various techniques. One way
is to use the formula min + random.nextInt(max - min + 1) to generate integers within the
range [min, max].
import java.util.Random;
public class RandomRangeExample {
public static void main(String[] args) {
Random random = new Random();
int min = 5;
int max = 15;
int randomInRange = min + random.nextInt(max - min + 1);
System.out.println("Random within Range: " +
randomInRange);
}
}
}CS205 Java Random Numbers FS 2024
3. Generating Random Doubles with java.util.Random
To generate random double values between 0.0 (inclusive) and 1.0 (exclusive), you can use the
nextDouble() method.
import java.util.Random;
public class RandomDoubleExample {
public static void main(String[] args) {
Random random = new Random();
double randomDouble = random.nextDouble();
System.out.println("Random Double: " + randomDouble);
}
}4. Generating Random within a Range with java.util.Random
To generate random numbers within a specific range, you can use various techniques. One way
is to use the formula min + random.nextInt(max - min + 1) to generate integers within the
range [min, max].
import java.util.Random;
public class RandomRangeExample {
public static void main(String[] args) {
Random random = new Random();
int min = 5;
int max = 15;
int randomInRange = min + random.nextInt(max - min + 1);
System.out.println("Random within Range: " +
randomInRange);
}
}
}
CS205 Java Random Numbers FS2024
5. Seeding the Random Generator with java.util.Random
By default, the Random class uses the current system time as its seed. However, you can
provide your own seed to produce a repeatable sequence of random numbers. This can be useful
for debugging or ensuring consistent behavior.
import java.util.Random;
public class SeededRandomExample {
public static void main(String[] args) {
long seed = 12345L;
Random random = new Random(seed);
int seededRandom = random.nextInt();
System.out.println("Seeded Random: " + seededRandom);
}
}
6. Generating Random Numbers with Math.random()
The Math.random() method generates a random double value between 0.0 (inclusive) and 1.0
(exclusive).
public class MathRandomExample {
public static void main(String[] args) {
double randomValue = Math.random();
System.out.println("Math.random() Value: " +
randomValue);
}
}
7. Example Applications
• Simulation: Simulating real-world scenarios in games, scientific experiments, or testing.
• Randomization: Shuffling elements, generating random passwords, or randomizing quiz
questions.
• Game Development: Randomly placing game objects, generating terrain, or determining
chances of events.
CS205 Java Random Numbers
• Cryptography: Creating encryption keys or initialization vectors.
8. Conclusion
Generating random numbers in Java is essential for various applications. You can use the
java.util.Random class or the Math.random() method to generate random numbers of different
types. Understanding these methods' usage can greatly enhance your ability to develop
applications that require randomness.
Remember that while the generated numbers are pseudorandom and not truly random, they are
generally sufficient for most applications. Always consider your specific requirements when
choosing a random number generation technique.








CS205 Main Method FS 2024
The main method in Java is arguably the most important method – it is the entry-point into any Java
program. The syntax is the same for any Java program. The JVM (Java Virtual Machine) executes
Java byte code, and the main method must have specific syntax for the JVM to identify it and
execute its contents.
public static void main(String[] args)
public: The method needs to be public for the JVM to identify it.
static: static in this context means that there will be only one type of this method and that it will be
shared. When we call the main method, it does not require a new instantiated object – it can be
called without the creation of a new object.
void: There is nothing returned from the main method.
main: The general signature of the main method that is identified by the JVM to execute any
program from start to finish.
String[] args: The main method's argument (or input parameter) is an array of type String . This
allows the method to accept command line arguments, which are stored as String s in this variable.
The name args can be changed.
Examples This method will be identified by the JVM and will execute accordingly assuming there are
no other errors.
public static void main(String [] args) {
System.out.println("Main Method");
}
Syntax
public static void main(String[] args)

*/