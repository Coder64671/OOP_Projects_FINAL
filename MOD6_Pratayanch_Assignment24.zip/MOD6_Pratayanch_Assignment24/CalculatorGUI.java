
/**
 * Write a description of class CalculatorGUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;

public class CalculatorGUI {
    private JFrame frame;
    private JTextField textField;
    private StringBuilder currentExpression;

    public CalculatorGUI() {
        // Create the main frame
        frame = new JFrame("Basic Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 400);

        // Create the text field for displaying expressions
        textField = new JTextField();
        textField.setFont(new Font("Arial", Font.PLAIN, 24));
        textField.setEditable(false); // Prevent user typing directly

        // Initialize the expression holder
        currentExpression = new StringBuilder();

        // Create a panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 4, 5, 5)); // Grid layout: 5 rows x 4 columns

        // Define button labels
        String[] buttonLabels = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", ".", "=", "+",
            "C"
        };

        // Create buttons and add them to the panel
        for (String label : buttonLabels) {
            JButton button = new JButton(label);
            button.setFont(new Font("Arial", Font.BOLD, 18));
            button.addActionListener(new ButtonClickListener());
            buttonPanel.add(button);
        }

        // Add components to the frame
        frame.setLayout(new BorderLayout());
        frame.add(textField, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);

        // Make the frame visible
        frame.setVisible(true);
    }

    // Listener class for button clicks
    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = ((JButton) e.getSource()).getText();

            switch (command) {
                case "=":
                    evaluateExpression();
                    break;
                case "C":
                    currentExpression.setLength(0); // Clear the input
                    textField.setText("");
                    break;
                default:
                    currentExpression.append(command); // Append the button text
                    textField.setText(currentExpression.toString());
                    break;
            }
        }

        private void evaluateExpression() {
            try {
                // Use the embedded ExpressionEvaluator to evaluate the expression
                ExpressionEvaluator evaluator = new ExpressionEvaluator();
                double result = evaluator.evaluate(currentExpression.toString());

                // Display the result in the text field
                textField.setText(Double.toString(result));

                // Reset the expression after evaluation
                currentExpression.setLength(0);
            } catch (Exception ex) {
                // Display error message for invalid expressions
                textField.setText("Error");
            }
        }
    }

    // Main method to run the program
    public static void main(String[] args) {
        SwingUtilities.invokeLater(CalculatorGUI::new);
    }

    // Embedded ExpressionEvaluator class
    private static class ExpressionEvaluator {
        public double evaluate(String expression) {
            // Remove any whitespace
            expression = expression.replaceAll("\\s+", "");

            // Stacks for numbers and operators
            Stack<Double> numbers = new Stack<>();
            Stack<Character> operators = new Stack<>();

            int i = 0;
            while (i < expression.length()) {
                char ch = expression.charAt(i);

                // Handle digits and decimal numbers
                if (Character.isDigit(ch) || ch == '.') {
                    StringBuilder number = new StringBuilder();
                    while (i < expression.length() && (Character.isDigit(expression.charAt(i)) || expression.charAt(i) == '.')) {
                        number.append(expression.charAt(i));
                        i++;
                    }
                    numbers.push(Double.parseDouble(number.toString()));
                    continue;
                }

                // Handle operators
                if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                    // Evaluate higher precedence operators first
                    while (!operators.isEmpty() && precedence(operators.peek()) >= precedence(ch)) {
                        performOperation(numbers, operators.pop());
                    }
                    operators.push(ch);
                }
                i++;
            }

            // Complete remaining operations
            while (!operators.isEmpty()) {
                performOperation(numbers, operators.pop());
            }

            // Result is the final number on the stack
            return numbers.pop();
        }

        private int precedence(char operator) {
            return switch (operator) {
                case '+', '-' -> 1;
                case '*', '/' -> 2;
                default -> -1;
            };
        }

        private void performOperation(Stack<Double> numbers, char operator) {
            double b = numbers.pop(); // Second operand
            double a = numbers.pop(); // First operand

            switch (operator) {
                case '+' -> numbers.push(a + b);
                case '-' -> numbers.push(a - b);
                case '*' -> numbers.push(a * b);
                case '/' -> numbers.push(a / b);
            }
        }
    }
}