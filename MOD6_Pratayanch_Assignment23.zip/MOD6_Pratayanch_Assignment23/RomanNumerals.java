import java.io.*;
import java.util.*;

/**
 * A class to convert Roman numerals to Arabic numerals.
 * It uses a HashMap to store Roman numeral values and converts Roman strings to Arabic integers.
 * The HashMap is populated from a file named "numbers.txt".
 * 
 * @author Pratayanch Sav (Krish)
 * @version 11/26/2024
 */
public class RomanNumerals {
    private HashMap<String, Integer> romanMap;

    /**
     * Constructor initializes the HashMap and populates it with Roman numeral values.
     */
    public RomanNumerals() {
        romanMap = new HashMap<>();
        populateMapFromFile("numbers.txt");
    }

    /**
     * Reads Roman numeral values from a file and populates the HashMap.
     * 
     * @param fileName The name of the file containing Roman numeral mappings.
     */
    private void populateMapFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                romanMap.put(parts[0], Integer.parseInt(parts[1]));
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }

    /**
     * Converts a Roman numeral string to an Arabic numeral.
     * 
     * @param roman The Roman numeral string.
     * @return The Arabic numeral equivalent of the Roman string, or -1 if invalid.
     */
    public int convertToArabic(String roman) {
        int result = 0;
        int previousValue = 0;

        for (int i = roman.length() - 1; i >= 0; i--) {
            char currentChar = roman.charAt(i);
            int currentValue = romanMap.getOrDefault(String.valueOf(currentChar), -1);

            if (currentValue == -1) {
                return -1; // Invalid Roman numeral character.
            }

            // Apply subtraction rule
            if (currentValue < previousValue) {
                result -= currentValue;
            } else {
                result += currentValue;
            }

            previousValue = currentValue;
        }

        return result <= 3999 ? result : -1; // Return -1 for values greater than 3999.
    }

    /**
     * Main method to run the Roman numeral converter program.
     * Prompts the user to enter Roman numerals or type 'exit' to quit.
     * 
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        RomanNumerals converter = new RomanNumerals();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter your Roman numeral string (or type 'exit' to quit): ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            int arabicValue = converter.convertToArabic(input);

            if (arabicValue == -1) {
                System.out.println("The Arabic value of " + input + ": could not be found. Illegal Roman numeral.");
            } else {
                System.out.println("The Arabic value of " + input + " is: " + arabicValue);
            }
        }

        scanner.close();
    }
}