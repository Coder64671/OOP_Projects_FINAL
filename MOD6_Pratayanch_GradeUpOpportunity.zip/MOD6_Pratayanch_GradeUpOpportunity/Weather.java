import java.util.Scanner;

public class Weather
{
    
    public Weather()
    {
        pickAndPrintCity();
    }
    
    public void pickAndPrintCity(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Pick one: Delhi, Pune, Mumbai");
        String choice = scanner.nextLine();
        System.out.println("Would you like the response in Farenheight or Celcius.");
        String temp = scanner.nextLine();
        if(choice.equals("Delhi")){
            System.out.println("The city you selected is: " + choice);
            if(temp.equals("Farenheight")){
                System.out.println("The temperature of this region is 80 degrees F.");
            }else{
                System.out.println("The temperature of thsi region is 27 degrees C.");
            }
        }else if(choice.equals("Pune")){
            System.out.println("The city you selected is: " + choice);
            if(temp.equals("Farenheight")){
                System.out.println("The temperature of this region is 79 degrees F.");
            }else{
                System.out.println("The temperature of thsi region is 26 degrees C.");
            }
        }else if(choice.equals("Mumbai")){
            System.out.println("The city you selected is: " + choice);
            if(temp.equals("Farenheight")){
                System.out.println("The temperature of this region is 84 degrees F.");
            }else{
                System.out.println("The temperature of thsi region is 29 degrees C.");
            }
        }else{
            System.out.println("Invalid response, please try again...");
            pickAndPrintCity();
        }
    }
}
